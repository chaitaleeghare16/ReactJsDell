import React from 'react';
import logo from './logo.svg';
import './App.css';
import Bootstrap from './Bootstrap'

import LogIn from './Project/LogIn';
import SignUp from './Project/SignUp';
import { Route, BrowserRouter, Switch } from 'react-router-dom';
import Admin from './Project/Admin';

function App() {
  return (
    <div className="App">
   
      
      
     
     
      
    </div>
  );
}

export default App;
