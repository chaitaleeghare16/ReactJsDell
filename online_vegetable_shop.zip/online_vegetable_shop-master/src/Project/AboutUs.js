import React, { Component } from "react";

export class AboutUs extends Component {
  render() {
    return <div>hii i am from about us</div>;
  }
}

export default AboutUs;
