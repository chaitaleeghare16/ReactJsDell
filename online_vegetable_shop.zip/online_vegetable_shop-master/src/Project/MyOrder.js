import React, { Component } from "react";

export class MyOrder extends Component {
  render() {
    return <div>from myorder</div>;
  }
}

export default MyOrder;
