import React, { Component } from "react";
import { ProductDisplayintoCart } from "./ProductDisplayintoCart";

class Cart extends React.Component {
  render() {
    return <div>{<ProductDisplayintoCart />})</div>;
  }
}

export default Cart;
