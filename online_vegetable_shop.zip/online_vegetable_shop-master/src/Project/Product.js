// import React from 'react'

// import Button from 'react-bootstrap/Button'
// import  styles from './Styles/Product.css'

//  export const Product=({key,id,img,name,price,stock,unit,count,addfun})=> {  //add to cart

//     return (

//         <ul class="list pl0 mt0 measure center">
//                 <li
//                     class="flex items-center lh-copy pa3 ph0-l bb b--black-10">
//                     <img class="w3 h3 w4-ns h4-ns br-100" src={img} />
//                     <div class="pl3 flex-auto">
//                         <span class="f6 db black-70">{name}</span>
//                          <span class="f6 db black-90"><strong>Price :</strong>{price}/{unit}</span>
//                         <span class="f6 db black-70">{stock}</span>
//                         {/* <span class="f6 db black-70">{units}</span> */}
//                         <button className='btn btn-danger'onClick={addfun({id,img,name,price,stock,unit,count})}>ADD to cart</button>

//                     </div>
//                     {/* <div>
//                         <button class="f6 link blue hover-dark-gray" >+</button>&nbsp;
//                         <span>0</span>&nbsp;
//                         <button class="f6 link blue hover-dark-gray">-</button>

//                     </div> */}
//                 </li>

//         </ul>

//     )
// }
// export default Product
