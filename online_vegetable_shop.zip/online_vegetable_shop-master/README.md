This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).



In the project directory, you can run:

### `npm start`

after this step click on sign up.create two users 1)admin 2)normal user
as of now default setting is normal user so you need to update admin user property(isAdmin:true) in localstorage 
